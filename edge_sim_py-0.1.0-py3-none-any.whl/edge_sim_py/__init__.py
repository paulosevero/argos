"""Automatic Python configuration file.
"""
__version__ = "0.1.0"
