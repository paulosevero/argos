# pylint: disable=unexpected-keyword-arg,no-value-for-parameter
""" Contains services functionality.
"""
from edge_sim_py.object_collection import ObjectCollection
import networkx as nx


class Service(ObjectCollection):
    """Class responsible for simulating services functionality."""

    # Class attribute that allows this class to use helper methods from ObjectCollection
    instances = []

    def __init__(self, obj_id: int = None, demand: int = None) -> object:
        """Creates a Service object.

        Args:
            obj_id (int, optional): Object identifier.
            demand (int, optional): Service demand.

        Returns:
            object: Created Service object.
        """
        self.id = obj_id

        self.demand = demand

        self.clients = []
        self.server = None
        self.application = None

        # List that stores metadata about each migration experienced by the service throughout the simulation
        self.migrations = []

        # Reference to the Simulator object
        self.simulator = None

        # Adding the new object to the list of instances of its class
        Service.instances.append(self)

    def __str__(self):
        """Defines how the object is represented inside print statements.

        Returns:
            str: Object representation.
        """
        return f"Service_{self.id}"

    def __repr__(self):
        """Defines how the object is represented inside the console.

        Returns:
            str: Object representation.
        """
        return f"Service_{self.id}"

    def migrate(self, target_server: object, path: list = []) -> int:
        """Migrates a service to a target server.

        Args:
            target_server (object): Target server.

        Returns:
            migration_time (int): Service migration time.
        """
        # Finding a network path to migrate the service to the target host in case path is not provided
        if len(path) == 0 and self.server is not None:
            path = nx.shortest_path(
                G=self.simulator.topology,
                source=self.server.base_station,
                target=target_server.base_station,
                weight="bandwidth",
            )
        else:
            path = []

        # Calculating service migration time
        migration_time = self.get_migration_time(path=path)

        # Storing migration metadata to post-simulation analysis
        self.migrations.append(
            {
                "step": self.simulator.current_step,
                "duration": migration_time,
                "origin": self.server,
                "destination": target_server,
                "number_of_links_used": len(path) - 1,
            }
        )

        # Removing the service from its old host
        if self.server is not None:
            self.server.demand -= self.demand
            self.server.services.remove(self)

        # Adding the service to its new host
        self.server = target_server
        self.server.demand += self.demand
        self.server.services.append(self)

        return migration_time

    def get_migration_time(self, path: list) -> int:
        """Calculates the time it takes to migrate a service using a given network path.

        Args:
            path (list): Network path used to transfer the service throughout the network.

        Returns:
            migration_time (int): Service migration time.
        """

        # NetworkX may return multiple shortest paths sometimes.
        # In these cases, we use the first one to migrate the service
        if isinstance(path, dict):
            path = list(path.values())[0]

        # Checks if the service is being migrated to a different host
        if len(path) > 1:
            # Finding the available bandwidth for the service migration
            bandwidth = min(
                [self.simulator.topology[link][path[index + 1]]["bandwidth"] for index, link in enumerate(path[:-1])]
            )

            # Calculating service migration time based on the service size and the available network bandwidth
            migration_time = 0
            for _ in range(len(path) - 1):
                migration_time += self.demand / bandwidth
        else:
            # Sets migration time to 0 if the service is not being migrated
            migration_time = 0

        return migration_time
