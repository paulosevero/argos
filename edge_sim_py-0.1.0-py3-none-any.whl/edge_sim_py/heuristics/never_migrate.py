""" Contains the Never Migrate heuristic."""


def never_migrate():
    """Simple strategy that performs no migration decision regardless users' mobility."""
    ...
